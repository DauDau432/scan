#pragma once

#include "main.h"

int check_password_resp(Brute *);
int check_login_resp(Brute *);