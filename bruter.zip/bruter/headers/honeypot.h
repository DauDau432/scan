#pragma once

int check_honeypot(Brute *);