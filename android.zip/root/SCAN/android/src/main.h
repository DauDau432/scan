#pragma once

enum
{
    TRUE = 1,
    FALSE = 0,
    STDIN = 0,
    STDOUT = 1,
    STDERR = 2,
    MAX_EVENTS = 1000000
};
